package edu.wit.cs.comp2000.tests;



import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.security.Permission;

 
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import edu.wit.cs.comp2000.StackInterface;
import edu.wit.cs.comp2000.ArrayStack;
/**
A class of stacks whose entries are stored in an array.
@author Frank M. Carrano, and Paul Sender
@version 2.1
*/
public class LAB2Tests{
	
	@Rule
	public Timeout globalTimeout = Timeout.seconds(5);
	
	@SuppressWarnings("serial")
	private static class ExitException extends SecurityException {}
	
	private static class NoExitSecurityManager extends SecurityManager 
    {
        @Override
        public void checkPermission(Permission perm) {}
        
        @Override
        public void checkPermission(Permission perm, Object context) {}
        
        @Override
        public void checkExit(int status) { super.checkExit(status); throw new ExitException(); }
    }
	
	@Before
    public void setUp() throws Exception 
    {
        System.setSecurityManager(new NoExitSecurityManager());
    }
	
	@After
    public void tearDown() throws Exception 
    {
        System.setSecurityManager(null);
    }
	
	private String[] getStringArray() {
		String[] ret = new String[6];
		
		ret[0] = "abc";
		ret[1] = "123";
		ret[2] = "hello";
		ret[3] = "abc";
		ret[4] = "123";
		ret[5] = "goodbye";
		
		return ret;
	}
	
	
	/*
	 * push does not return a value, so we check to make sure 
	 * our implementation doesn't crash and check exceptions
	 */
	@Test
	public void testPush() {
		String[] arr = getStringArray();
		StackInterface<String> testStack = new ArrayStack<>();
		
		boolean exceptionDetected = false;
		
		testStack = new ArrayStack<>(3); 
		
		// check that each add call is successful
		for (int i = 0; i < 3; i++)
			testStack.push(arr[i]);
		
		exceptionDetected = false;
		try {
			testStack.push(arr[3]);
		} catch (SecurityException e) {
			exceptionDetected = true;
		}
		
		assertTrue("Pushing onto a full stack should throw SecurityException", exceptionDetected);
		
	}

	
	@Test
	public void testIsEmpty() {
		StackInterface<String> testStack = new ArrayStack<>();
		

		assertTrue("Stack should start out empty", testStack.isEmpty());
		
		testStack.push("testing");
		assertTrue("Stack should not be empty with 1 entry", !testStack.isEmpty());
		
		testStack.push("more testing");
		assertTrue("Stack should not be empty with 2 entries", !testStack.isEmpty());
	}
	
	
	@Test
	public void testPop() {
		String[] arr = getStringArray();
		StackInterface<String> testStack = new ArrayStack<>();
		String s = " ";
		int len = arr.length;
		//creates a new stack of size - whatever the size of the array imported is
		testStack = new ArrayStack<>(arr.length); 
		//loops through the array and extracts then adds to stack all elements in the array
		for (int i = 0; i < arr.length;i++) {
			testStack.push(arr[i]); 
			
		}
		//Finds returns, and removes the top element in the stack
		s = testStack.pop();
		len--;
		assertTrue("Pop is not taking out the last element in our stack", !s.equals(arr[0]));
		assertTrue("The pop didn't remove..", len < arr.length);
		assertTrue("Empty stack...", !testStack.isEmpty()); 
	}
	
	
	@Test
	public void testPeek() {
		String[] arr = getStringArray();
		String s = "";
		StackInterface<String> testStack = new ArrayStack<>();
		//creates a new stack of size - whatever the size of the array imported is
		testStack = new ArrayStack<>(arr.length); 
		//loops through the array and extracts then adds to stack all elements in the array
		for (int i=0; i<arr.length -1;i++) {
			testStack.push(arr[i]);
		}
		//Finds and returns the top element in the stack
		s = testStack.peek();
		
		assertTrue("We're not peeking at the top of the stack...", !s.equals(arr[0])); 
		assertTrue("Empty stack...",!testStack.isEmpty());
	}
	
	
	@Test
	public void testClear() {
		String[] arr = getStringArray();
		StackInterface<String> testStack = new ArrayStack<>();
		//creates a new stack of size - whatever the size of the array imported is
		
		
		
		testStack = new ArrayStack<>(arr.length); 
		//fills the stack
		for (int i = 0; i < arr.length;i++) {
			testStack.push(arr[i]);
			//System.out.println(testStack.pop());
			
		}
		
		//clears the stack
		testStack.clear();
		//If the stack is empty there should be no error
		assertTrue("Not empty", testStack.isEmpty()); 
		
	}
	
}
